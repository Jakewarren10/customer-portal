
# Customer Portal App

This is a full-featured FastAPI application where users can register, log in, submit data, and view dashboard interactions. Styled with Tailwind-inspired CSS like Whip-Around UI.

## Features
- User authentication (register/login/logout)
- Flash messages & toast notifications
- Submit and store data
- Dark mode toggle
- Responsive HTML templates
- Jinja2 templating
- SQLite database

## Requirements
- Python 3.9+
- pip

## Installation

```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

Then visit: `http://localhost:8000`

## Environment
Ensure this is installed:
```bash
pip install fastapi uvicorn sqlalchemy jinja2 passlib[bcrypt]
```

## Run with Docker
```bash
docker build -t customer-portal .
docker run -p 8000:8000 customer-portal
```
