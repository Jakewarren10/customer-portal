
from fastapi import FastAPI, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from passlib.hash import bcrypt
from pydantic import BaseModel
from starlette.middleware.sessions import SessionMiddleware
from sqlalchemy import create_engine, Column, Integer, String, ForeignKey, Text, DateTime
from sqlalchemy.orm import sessionmaker, declarative_base, relationship
from datetime import datetime
import uvicorn

app = FastAPI()
app.add_middleware(SessionMiddleware, secret_key="super-secret-key")

# Database setup
engine = create_engine("sqlite:///db.sqlite3", connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Models
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    email = Column(String, unique=True, index=True)
    hashed_password = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
    submissions = relationship("Submission", back_populates="user")

class Submission(Base):
    __tablename__ = "submissions"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    submitted_data = Column(Text)
    timestamp = Column(DateTime, default=datetime.utcnow)
    user = relationship("User", back_populates="submissions")

Base.metadata.create_all(bind=engine)

# Templates & Static
app.mount("/static", StaticFiles(directory="static"), name="static")

from starlette.responses import RedirectResponse
from starlette.templating import _TemplateResponse

templates = Jinja2Templates(directory="templates")

# Inject flash message into context
@templates.context_processor
def inject_flash(request: Request):
    flash = request.session.pop("flash", None)
    return {"flash": flash}


# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def get_current_user(request: Request, db):
    user_id = request.session.get("user_id")
    if not user_id:
        return None
    return db.query(User).filter(User.id == user_id).first()

# Routes
@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("home.html", {"request": request})

@app.get("/register", response_class=HTMLResponse)
def register_get(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

@app.post("/register")
def register_post(request: Request, email: str = Form(...), password: str = Form(...), db=Depends(get_db)):
    user = db.query(User).filter(User.email == email).first()
    if user:
        raise HTTPException(status_code=400, detail="Email already registered")
    new_user = User(email=email, hashed_password=bcrypt.hash(password))
    db.add(new_user)
    db.commit()
    request.session['flash'] = 'Registration successful. Please log in.'
    return RedirectResponse("/login", status_code=302)

@app.get("/login", response_class=HTMLResponse)
def login_get(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/login")
def login_post(request: Request, email: str = Form(...), password: str = Form(...), db=Depends(get_db)):
    user = db.query(User).filter(User.email == email).first()
    
    if not user or not bcrypt.verify(password, user.hashed_password):
        request.session["flash"] = "Invalid email or password."
        return RedirectResponse("/login", status_code=302)

    request.session["user_id"] = user.id
    request.session['flash'] = 'Logged in successfully.'
    request.session['flash'] = 'Data submitted successfully.'
    return RedirectResponse("/dashboard", status_code=302)

@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request, db=Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login")
    return templates.TemplateResponse("dashboard.html", {"request": request, "user": user})

@app.get("/submit", response_class=HTMLResponse)
def submit_get(request: Request, db=Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login")
    return templates.TemplateResponse("submit.html", {"request": request})

@app.post("/submit")
def submit_post(request: Request, data: str = Form(...), db=Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login")
    submission = Submission(user_id=user.id, submitted_data=data)
    db.add(submission)
    db.commit()
    request.session['flash'] = 'Logged in successfully.'
    request.session['flash'] = 'Data submitted successfully.'
    return RedirectResponse("/dashboard", status_code=302)

@app.get("/logout")
def logout(request: Request):
    request.session.clear()
    request.session['flash'] = 'You have been logged out.'
    return RedirectResponse("/")

if __name__ == "__main__":
    uvicorn.run("main:app", reload=True)
